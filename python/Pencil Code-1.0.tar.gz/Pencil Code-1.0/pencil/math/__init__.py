import numpy as N

from vector_multiplication import *
from derivatives import *
