#!/usr/bin/env python

from distutils.core import setup

setup(name='Pencil Code',
      version='1.0',
      description='Python Pencil Code Utilities',
      author='Illa R. Losada',
      author_email='illa.rivero.losada@gmail.com',
      #py_modules=['pencil'],
      packages=['pencil','pencil.files','pencil.math','pencil.math.derivatives']
      #package_dir = {'pencil':'files'}
     )

